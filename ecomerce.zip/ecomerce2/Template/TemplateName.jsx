import React from 'react'
import "./TemplateName.css";
export default function TemplateName() {
  return <>
  <div>TemplateName</div>
  </>
  
}
