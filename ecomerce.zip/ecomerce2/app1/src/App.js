
import './App.css';
import  { Toaster } from 'react-hot-toast';
import  { QueryClient, QueryClientProvider } from 'react-query'
import { createBrowserRouter,RouterProvider} from "react-router-dom";
import Layout from './components/Layout/Layout';
import Login from './components/Login/Login';
import MyAllProduct from './components/MyAllProduct/MyAllProduct';
import Home from './components/Home/Home';
import { MyContextProvider } from './components/ContextApp/ContextApp';
import Register from './components/Register/Register';
import ProtectedRouter from './components/ProtectedRouter/ProtectedRouter';
import Proudectdetails from './components/Proudectdetails/Proudectdetails';
import Cart from './components/Cart/Cart';
import CreateCashOrder from './components/CreateCashOrder/CreateCashOrder';
import Allorders from './components/Allorders/Allorders';

function App() {

  let queryClient = new QueryClient()

let router = createBrowserRouter([
  {   path: '', element:<Layout/> , children:[
    { path: 'login' , element:<Login/>},
    { index: true , element:<Home/>},
    { path: 'register' , element:<Register/>},
    { path: 'MyAllProduct' , element:<ProtectedRouter><MyAllProduct/></ProtectedRouter>},
    { path: 'Proudectdetails/:id' , element:<ProtectedRouter><Proudectdetails/></ProtectedRouter>},
    { path: 'Cart' , element:<ProtectedRouter><Cart/></ProtectedRouter>},
    { path: 'CreateCashOrder/:id' , element:<ProtectedRouter><CreateCashOrder/></ProtectedRouter>},
    { path: 'allorders' , element:<ProtectedRouter><Allorders/></ProtectedRouter>},

    
  ]}
])

  return <>
<  QueryClientProvider client={queryClient}>
<MyContextProvider>
<Toaster/>
<RouterProvider router={router}></RouterProvider>
</MyContextProvider>
</QueryClientProvider>
  </>
}

export default App;
