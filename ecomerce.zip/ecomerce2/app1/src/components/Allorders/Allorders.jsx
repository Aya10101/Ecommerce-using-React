import React, { useContext, useEffect, useState } from 'react';
import { contextApp } from '../ContextApp/ContextApp';
import toast from 'react-hot-toast';
import cart from '../../img/emtyCart.png';
import { Link } from 'react-router-dom';

export default function Allorders() {
  const { GetAllProductToCart  } = useContext(contextApp);
  const [loading, setLoading] = useState(true);
  const [detailsInCart, setDetailsInCart] = useState([]);
  const [productDetails, setProductDetails] = useState([]);

  async function fetchCartProducts() {
    setLoading(true);
    try {
      const response = await GetAllProductToCart();
      setProductDetails(response.data.data.products);
      setDetailsInCart(response.data.data);
      console.log("Cart details: ", response);
      if (response.statusMsg == "fail")
      {
        setProductDetails(null)
      }
   
    } catch (error) {
      toast.error('Cart is Empty :(');

    }
    setLoading(false);
  }

  useEffect(() => {
    fetchCartProducts();
  }, []);


  return   <>

     { productDetails.length > 0 ? (
        detailsInCart && (
          <div className="container mt-5 d-flex justify-content-center align-items-center">
            <div className="row py-3">

           <h3>All Order</h3>
  
              <div className="col-md-12 col-lg-12 col-xl-12">
                <div className="bg-main-light">
                  <div className="d-flex justify-content-end">
                    {/* <button className='btn mt-4 px-2 py-1 remove-main' >Clear all Product in Cart</button> */}
                  </div>
                  {productDetails.filter((product) => product.count > 0).map((product) => (
                    <div key={product._id} className="row d-flex align-items-center border-top py-1 m-1 ps-0">
                      <div className="col-md-2">
                        <div className="imgs p-2">
                          <img src={product.product.imageCover} className="w-100" alt="" />
                        </div>
                      </div>
                      <div className="col-md-10">
                        <div className="row align-items-center justify-content-between ps-0">
                          <div className="col-md-6">
                            <h5 className="second-color fw-bolder">{product.product.title.split(' ').slice(0, 3).join(' ')}</h5>
                            <span className="pb-1">Added to Cart: <span className="header-color">{detailsInCart.createdAt.split("T")[0]}</span></span>
                            <div className="d-flex">
                              <span className="spanColor">Rating Average: </span>
                              <span className="d-block"><i className="fas fa-star star-color"></i>{product.product.ratingsAverage}</span>
                            </div>
                            <div className="d-flex">
                              <span className="spanColor">Brand: </span>
                              <span className="d-block">{product.product.brand.name}</span>
                            </div>
                          </div>
                          <div className="col-md-6">
                            <div className="row align-items-end justify-content-between ps-0">
                              <div className="col-md-5">
                                <h6 className="second-color pt-1">Price: <span className="header-color">{product.price} EGP</span></h6>
                              </div>
                          
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
           
            </div>
          </div>
        )
      ) : (
        <div className="d-flex justify-content-center align-items-center">
          <img src={cart} alt="Shop Store ecommerce" className='w-75' />
        </div>
    
  )};
  </>
  
}
