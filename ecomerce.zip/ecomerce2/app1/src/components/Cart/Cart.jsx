import React, { useContext, useEffect, useState } from 'react';
import { contextApp } from '../ContextApp/ContextApp';
import toast from 'react-hot-toast';
import cart from '../../img/emtyCart.png';
import { Link } from 'react-router-dom';
import {Helmet} from "react-helmet";  

export default function Cart() {
  const { GetAllProductToCart, removeCartItem, updateCartItem, ClearAllProductInCart } = useContext(contextApp);
  const [productDetails, setProductDetails] = useState([]);
  const [detailsInCart, setDetailsInCart] = useState([]);
  const [loading, setLoading] = useState(true);

  let headers = { token: localStorage.getItem('yourToken') };

  async function removeOnlyProduct(idItem) { 
    try {
      let response = await removeCartItem(idItem);
      setDetailsInCart(response.data.data);
      setProductDetails(response.data.data.products);
      toast.success('The product has been successfully removed', {
        style: {
          backgroundColor: 'white',
          padding: '10px',
          textAlign: 'center',
          color: 'black',
        },
      });
    } catch (error) {
      toast.error('Failed to remove product from cart.');
    }

  }

  async function updateProduct(Count, idItem) {
    try {
      let response = await updateCartItem(Count, idItem);
      setDetailsInCart(response.data.data);
      setProductDetails(response.data.data.products);
      toast.success('The product has been successfully updated', {
        style: {
          backgroundColor: 'white',
          padding: '10px',
          textAlign: 'center',
          color: 'black',
        },
      });
    } catch (error) {
      toast.error('Failed to update cart product.');
    }

  }

  async function clearAllProducts() {
    try {
      let response = await ClearAllProductInCart();
      setDetailsInCart(response.data.data);
      setProductDetails(response.data.data.products);
      toast.success('All products have been successfully removed', {
        style: {
          backgroundColor: 'white',
          padding: '10px',
          textAlign: 'center',
          color: 'black',
        },
      });
    } catch (error) {
      toast.error('Failed to clear cart products.');
    }
  }

  async function fetchCartProducts() {
    setLoading(true);
    try {
      const response = await GetAllProductToCart();
      setProductDetails(response.data.data.products);
      setDetailsInCart(response.data.data);
      console.log("Cart details: ", response);
      if (response.statusMsg == "fail")
      {
        setProductDetails(null)
      }
   
    } catch (error) {
      toast.error('Cart is Empty :(');

    }
    setLoading(false);
  }

  useEffect(() => {
    fetchCartProducts();
  }, []);

  return (
    <>

<Helmet>
                <meta charSet="utf-8" />
                <title>Your Cart </title>
                <meta name="description" content="Welcome to Your eCommerce Store, the best place to find and purchase the latest products. Shop now for electronics, fashion, home goods, and more. Enjoy fast shipping and excellent customer service." />
                <meta name="keywords" content="ecomerce Shop Store shoping fashion"/>
                <link rel="canonical" href="http://mysite.com/example" />
         
            </Helmet>

      {loading ? (
        <div className="d-flex justify-content-center align-items-center" style={{ height: '100vh' }}>
          <span className="loader"></span>
        </div>
      ) : productDetails.length > 0 ? (
        detailsInCart && (
          <div className="container mt-5 d-flex justify-content-center align-items-center">
            <div className="row py-3">
              <div className="col-md-12 col-lg-9 col-xl-9">
                <div className="bg-main-light">
                  <div className="d-flex justify-content-end">
                    <button className='btn mt-4 px-2 py-1 remove-main' onClick={clearAllProducts}>Clear all Product in Cart</button>
                  </div>
                  {productDetails.filter((product) => product.count > 0).map((product) => (
                    <div key={product._id} className="row d-flex align-items-center border-top py-1 m-1 ps-0">
                      <div className="col-md-2">
                        <div className="imgs p-2">
                          <img src={product.product.imageCover} className="w-100" alt="" />
                        </div>
                      </div>
                      <div className="col-md-10">
                        <div className="row align-items-center justify-content-between ps-0">
                          <div className="col-md-6">
                            <h5 className="second-color fw-bolder">{product.product.title.split(' ').slice(0, 3).join(' ')}</h5>
                            <span className="pb-1">Added to Cart: <span className="header-color">{detailsInCart.createdAt.split("T")[0]}</span></span>
                            <div className="d-flex">
                              <span className="spanColor">Rating Average: </span>
                              <span className="d-block"><i className="fas fa-star star-color"></i>{product.product.ratingsAverage}</span>
                            </div>
                            <div className="d-flex">
                              <span className="spanColor">Brand: </span>
                              <span className="d-block">{product.product.brand.name}</span>
                            </div>
                          </div>
                          <div className="col-md-6">
                            <div className="row align-items-end justify-content-between ps-0">
                              <div className="col-md-5">
                                <h6 className="second-color pt-1">Price: <span className="header-color">{product.price} EGP</span></h6>
                              </div>
                              <div className="col-md-5">
                                <button onClick={() => updateProduct(product.count + 1, product.product.id)} className="border-main btn-sm">+</button>
                                <span className="px-2 fw-bold">{product.count}</span>
                                <button onClick={() => updateProduct(product.count - 1, product.product.id)} className="border-main btn-sm">-</button>
                              </div>
                              <div className="col-md-2">
                                <button onClick={() => removeOnlyProduct(product.product.id)} className="btn mt-4 px-2 py-1 remove-main">
                                  <i className="fa-solid fa-trash-can"></i>
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="col-md-12 col-lg-3 col-xl-3 mt-2">
                <div className="contentsCart p-3 border shadow-sm rounded-3">
                  <h5 className='header-color fw-bold'>Shop Cart:</h5>
                  <div className="d-flex justify-content-between mb-3 border-bottom">
                    <label htmlFor="" className="mt-2">Coupon Code</label>
                  </div>
                  <input type="text" className="form-control mb-2" placeholder="Enter Coupon Code" />
                  <span className="font-sm text-muted">Coupon code will be applied on the checkout page</span>
                  <div className="d-flex justify-content-between mt-4 border-top pt-1">
                    <span>Total Cart Price: </span>
                    <h3 className="h6 header-color"><span className='header-color'>{detailsInCart.totalCartPrice} EGP</span></h3>
                  </div>
                  <Link to={`/CreateCashOrder/${detailsInCart._id}`} className="btn bg-success success-colors text-white mt-3  w-100">Proceed To Checkout</Link>
                </div>
              </div>
            </div>
          </div>
        )
      ) : (
        <div className="d-flex justify-content-center align-items-center">
          <img src={cart} alt="Shop Store ecommerce" className='w-75 mt-5' />
        </div>
      )}
    </>
  );
}
