import React, { createContext, useState, useEffect } from 'react';
import { useQuery } from 'react-query';
import toast from 'react-hot-toast';
import axios from 'axios';

export const contextApp = createContext();

export function MyContextProvider(props) {
  const [Product, setProduct] = useState([]);
  const [Category, setCategory] = useState([]);
  const [Brand, setBrand] = useState([]);
  const [CartNumber, setCartNumber] = useState(0);

  async function getAllproducts() {
    return await axios.get('https://ecommerce.routemisr.com/api/v1/products');
  }

  const { data: productsData } = useQuery('Allproducts', getAllproducts, {
    refetchOnMount: false,
    refetchInterval: 1000 * 60 * 60,
  });

  async function getAllCategory() {
    return await axios.get('https://ecommerce.routemisr.com/api/v1/categories');
  }

  const { data: category } = useQuery('AllCategory', getAllCategory, {
    refetchOnMount: false,
    refetchInterval: 1000 * 60 * 60,
  });

  async function getAllBrand() {
    return await axios.get('https://ecommerce.routemisr.com/api/v1/brands');
  }

  const { data: brand } = useQuery('AllBrand', getAllBrand, {
    refetchOnMount: false,
    refetchInterval: 1000 * 60 * 60,
  });

  useEffect(() => {
    if (productsData) {
      setProduct(productsData.data.data);
    }
  }, [productsData]);

  useEffect(() => {
    if (category) {
      setCategory(category.data.data);
    }
  }, [category]);

  useEffect(() => {
    if (brand) {
      setBrand(brand.data.data);
    }
  }, [brand]);

  let headers = { token: localStorage.getItem('yourToken') };

  async function AddProductToCart(id) {
    let response = await axios.post(
      'https://ecommerce.routemisr.com/api/v1/cart',
      { productId: id },
      { headers: headers }
    );
    toast.success('The product has been successfully added', {
      style: {
        backgroundColor: 'white',
        padding: '10px',
        textAlign: 'center',
        color: 'black',
      },
    });
    updateCartNumber();
  }

  async function GetAllProductToCart() {
    return await axios.get('https://ecommerce.routemisr.com/api/v1/cart', { headers: headers });
  }

  async function updateCartNumber() {
    if (localStorage.getItem('yourToken') != null) {
      let { data } = await GetAllProductToCart();
      setCartNumber(data.numOfCartItems);
    }
  }

  function removeCartItem(idItem) {
    return axios
      .delete(`https://ecommerce.routemisr.com/api/v1/cart/${idItem}`, { headers: headers })
      .then((response) => {
        updateCartNumber();
        return response;
      })
      .catch((error) => error);
  }

  function updateCartItem(counts, idItem) {
    return axios
      .put(`https://ecommerce.routemisr.com/api/v1/cart/${idItem}`, { count: counts }, { headers: headers })
      .then((response) => {
        updateCartNumber();
        return response;
      })
      .catch((error) => error);
  }

  function ClearAllProductInCart() {
    return axios
      .delete('https://ecommerce.routemisr.com/api/v1/cart', { headers: headers })
      .then((response) => {
        updateCartNumber();
        return response;
      })
      .catch((error) => error);
  }

  useEffect(() => {
    updateCartNumber();
  }, []);


  function OnlinePayment(cartId , url , values   ) 
  { return axios.post(`https://ecommerce.routemisr.com/api/v1/orders/checkout-session/${cartId}?url=http://${url}`,
    {
      shippingAddress:values
    },{
      headers: headers
    }
      
    ).then((response) => response)
      .catch((error) => error)
  }

  return (
    <contextApp.Provider
      value={{
        Product,
        Category,
        Brand,
        CartNumber,
        AddProductToCart,
        GetAllProductToCart,
        removeCartItem,
        updateCartItem,
        ClearAllProductInCart,
        OnlinePayment
      }}
    >
      {props.children}
    </contextApp.Provider>
  );
}
