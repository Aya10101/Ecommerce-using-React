import axios from 'axios';
import { useFormik } from 'formik'
import React, { useContext, useState } from 'react'
import toast from 'react-hot-toast';
import { contextApp } from '../ContextApp/ContextApp';
import { useParams } from 'react-router-dom';


export default function CreateCashOrder() {

let {OnlinePayment}= useContext(contextApp)
let { id } = useParams()

 async function handleSubmit(values ) {
 let response = await OnlinePayment( id ,'localhost:3004' , values )
 window.location.href =response?.data.session.url

}

let formik = useFormik({
  initialValues: {
      details: '',
      phone: '',
      city:" "
    },
    onSubmit: handleSubmit
  })
  return <>
  <div className="ContainerBackground">
  <div className="container my-5">
<form onSubmit={formik.handleSubmit} className=' shadow-lg p-5 rounded-3 border' >

<label htmlFor="name" className='my-2'> User Name:</label>
<input className='form-control' id="name" name="name" type="text" onBlur={formik.handleBlur} onChange={formik.handleChange} />


<label htmlFor="phone" className='my-2'>Phone: </label>
<input className='form-control' id="phone" name="phone" type="phone" onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.phone}/>
{formik.errors.phone && formik.touched.phone ? <div className="alert alert-danger">{formik.errors.phone}</div> : null } 

<label htmlFor="city" className='my-2'>City: </label>
<input className='form-control' id="city" name="city" type="text" onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.city}/>
{formik.errors.city && formik.touched.city ? <div className="alert alert-danger">{formik.errors.city}</div> : null } 


<label htmlFor="details" className='my-2'>Address: </label>
<input className='form-control' id="details" name="details" type="text" onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.details}/>
{formik.errors.details && formik.touched.details ? <div className="alert alert-danger">{formik.errors.details}</div> : null } 




<div className="d-flex justify-content-end">
<button type= 'submit' className='btn bg-main success-colors text-white mt-3  px-4 '> Pay Now <i className="fa-solid fa-circle-check"></i></button>
</div>
 </form>
</div>

  </div>

  </>
  
}
