import React from 'react'
import logo from '../../img/logo.svg'
import icon1 from '../../img/icon1.svg'
import icon2 from '../../img/icon2.svg'
import icon3 from '../../img/icon3.svg'
import icon4 from '../../img/icon4.svg'
import icon5 from '../../img/icon5.svg'
import icon6 from '../../img/icon6.png'
import img10 from '../../img/img10.png'
import img11 from '../../img/img11.png'
import img14 from '../../img/img14.png'
export default function Footer() {
  return<>
  <footer >
<div className="container-fluid">
<div className="d-flex justify-content-end py-2 align-items-center">

<div>
  <span className='px-2'><i className="fa-solid fa-envelope"></i> ayaa14213@gmail.com</span> | 
  <span className='px-2'><i className="fa-solid fa-phone"></i> 01118567923</span>
</div>
</div>
<hr />
<div className="container-fluid">
<div className="row">
  <div className="col-md-3 ">
    <div>
      <ul className="fa-ul">
      <h5>ELECTRONICS</h5>
  <li><span className="fa-li text-muted"></span>Mobiles  </li>
  <li><span className="fa-li text-muted"></span>Tablets  </li>
  <li><span className="fa-li text-muted"></span>Laptops  </li>
  <li><span className="fa-li text-muted"></span>Home Appliances  </li>
  <li><span className="fa-li text-muted"></span>Camera, Photo & Video  </li>
  <li><span className="fa-li text-muted"></span>Televisions  </li>


</ul>
    </div>
  </div>
  <div className="col-md-3 border-start ">
    <div>
      <ul className="fa-ul border-2 border-light ">
      <h5>Help</h5>
  <li><span className="fa-li text-muted"></span>Target Help  </li>
  <li><span className="fa-li text-muted"></span>Returns  </li>
  <li><span className="fa-li text-muted"></span>Track Orders  </li>
  <li><span className="fa-li text-muted"></span>Recalls   </li>
  <li><span className="fa-li text-muted"></span>Contact Us  </li>
  <li><span className="fa-li text-muted"></span>Feedback  </li>
 
</ul>
    </div>
  </div>
  <div className="col-md-3">
    <div>
      <ul className="fa-ul">
      <h5>TOP BRANDS</h5>
  <li><span className="fa-li text-muted"></span>Apple   </li>
  <li><span className="fa-li text-muted"></span>Samsung  </li>
  <li><span className="fa-li text-muted"></span>Nike   </li>
  <li><span className="fa-li text-muted"></span>Ray-Ban   </li>
  <li><span className="fa-li text-muted"></span>Tefal  </li>
  <li><span className="fa-li text-muted"></span>L'Oreal Paris  </li>


</ul>
    </div>
  </div>

  <div className="col-md-3">
    <div>
      <h5 className='ms-4'>Services</h5>
      <ul className="fa-ul">
  <li className='pb-2'><span className="fa-li text-muted"><img src={logo} alt="" width={20} /></span>Target Circle™  </li>
  <li className='pb-2'><span className="fa-li text-muted"><img src={icon2} alt="" width={20} /></span>Target Circle™ Card  </li>
  <li className='pb-2'><span className="fa-li text-muted"><img src={icon2} alt="" width={20} /></span>Target Circle 360™  </li>
  <li className='pb-2'><span className="fa-li text-muted"><img src={icon3} alt="" width={20} /></span>Home Appliances  </li>
  <li className='pb-2'><span className="fa-li text-muted"><img src={logo} alt="" width={20} /></span>Camera, Photo & Video  </li>

</ul>
    </div>
  </div>
</div>
</div>
<hr className='m-0 p-0' />

<img src={img14} alt="ecomerce shop Store"  className='w-100'  />
</div>
  </footer>
  </>
  
}
