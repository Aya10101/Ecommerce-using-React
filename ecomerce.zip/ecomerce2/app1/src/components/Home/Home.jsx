import React from 'react'
import HomeHeader from '../HomeHeader/HomeHeader';
import Slidercategories from '../Slidercategories/Slidercategories';
import SliderBrand from '../SliderBrand/SliderBrand';
import HomeSection1 from '../HomeSection1/HomeSection1';
import HomeSection2 from '../HomeSection2/HomeSection2';
import SimpleProduct from '../SimpleProduct/SimpleProduct';
import HomePoducts from '../HomePoducts/HomePoducts';
import {Helmet} from "react-helmet";
import logo from '../../img/logo.svg';
export default function Home() {
  return <>
 <Helmet>
                <meta charSet="utf-8" />
                <title>Home</title>
                <meta name="description" content="Welcome to Your eCommerce Store, the best place to find and purchase the latest products. Shop now for electronics, fashion, home goods, and more. Enjoy fast shipping and excellent customer service." />
                <meta name="keywords" content="ecomerce Shop Store shoping fashion"/>
                <link rel="canonical" href="http://mysite.com/example" />
                <link rel="icon" href={logo} type="image/png"/>
            </Helmet>
<HomeHeader/>
<SimpleProduct/>
<HomeSection2/>
<HomeSection1/>
<Slidercategories/>
<SliderBrand/>
<HomePoducts/>
  </>
  
}
