import React from 'react'
import "./HomeBrands.css";
export default function HomeBrands() {
  return <>
  <div>HomeBrands</div>
  </>
  
}
