import React from 'react'
import logo from '../../img/img1.webp'
import img2 from '../../img/img2.webp'
import img3 from '../../img/img3.webp'
import img4 from '../../img/img6.webp'
// import img4 from '../../img/img7.webp'
import "./HomeHeader.css";
export default function HomeHeader() {
  return <>
  <div className='w-100 container text-center HomeHeader mt-2'>

<img src={logo} alt=" Sale Shop Store" className='w-100 imgHeader ' />
<div className='secon-color px-4 '>
<h1>Hot deals for the best days!</h1>
<div className="row">
<div className="col-md-4">
  <img src={img2} alt="Sale Shop Store" className='rounded-3' />
  <h3>tees, tanks & swim for all*</h3>
</div>
<div className="col-md-4">
  <img src={img4} alt="Sale Shop Store" className='rounded-3' />
  <h3>Sun Squad™ pools, floats, water toys & more*</h3>
</div>

<div className="col-md-4">
  <img src={img3} alt="Sale Shop Store" className='rounded-3' />
  <h3>tees, tanks & swim for all*</h3>
</div>

</div>
</div>
  </div>
  </>
  
}
