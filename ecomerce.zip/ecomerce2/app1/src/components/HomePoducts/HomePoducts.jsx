import React, { useContext } from 'react';
import img1 from '../../img/img24.avif'
import img19 from '../../img/img19.webp'
import img20 from '../../img/img20.webp'
import img21 from '../../img/img21.webp'
import img22 from '../../img/img22.webp'
import img23 from '../../img/img23.webp'
import img9 from '../../img/img9.webp'
import img18 from '../../img/img18.jpg'
import { contextApp } from '../ContextApp/ContextApp';
import vedio from '../../img/game.mp4';
import { Link } from 'react-router-dom';

export default function HomePoducts() {
  const { Product, isLoading, isError ,AddProductToCart } = useContext(contextApp);

  if (isLoading) return <div>Loading...</div>;
  if (isError) return <div>Error fetching data</div>;

  async function addTocart(productId) {
    await AddProductToCart(productId);


  }
  return (
    <div className="container my-5">
      <div className="row g-3">


        <div className="video-container position-relative">
          <video autoPlay muted loop className="video">
            <source src={vedio} type="video/mp4" className='Vediosource' />
          </video>
          <div className='position-absolute top-50  translate-middle-y z-3 text-overlay text-start'>
            <h1 className='text-white m-0'>PLAY LIKE </h1>

            <h1 className='text-white m-0 p-0'> NEVER BEFORE</h1>
            <p></p>
          </div>
        </div>

        <div className="d-flex justify-content-between">
          <h3>New Electronics  </h3>
          <Link to="/MyAllProduct" className=' header-color'>shwo All Product <i className="fa-solid fa-angles-right fa-fade"></i></Link>
        </div>


        {Product.slice(34, 40).map((product) => (
          <div className=" col-sm-6 col-md-4  col-lg-4  col-xl-3  col-xxl-2  p-2" key={product.id}>

            <div className='productContent'>
              <Link to={`/Proudectdetails/${product.id}`} className='text-black'>
                <img src={product.imageCover} alt="Shop Store ecommerce" className='w-100' />
                <span className='text-success fw-bold'>
                  {product.title.split(' ').slice(0, 2).join(' ')}
                </span>
                <p className='text-muted'>{product.description.split(' ').slice(0, 5).join(' ')}</p>
                <div className="d-flex justify-content-between align-items-center">
                  <p>EGP<span className='fw-bold'>{product.price}</span> </p>
                  <p>{product.ratingsAverage} <i className="fa-solid fa-star star-color"></i> ({product.ratingsQuantity})</p>
                </div>
              </Link>
              <button onClick={()=>addTocart(product.id)}  className='btn text-center w-100 text-white AddToCart'>
                        Add to Cart <i className="fa-solid fa-cart-plus"></i>
                      </button>
              <div className='position-absolute p-2 heartContainer'>
                <i className="fa-regular fa-heart text-muted"></i>
              </div>
            </div>

          </div>
        ))}



        <div className='container mb-2 mt-5 position-relative HomeSection2'>
          <img src={img1} alt="" className='imgHeader2' />

        </div>


        <div className="d-flex justify-content-between">
          <h3>Women's fashion</h3>
          <Link to="/MyAllProduct" className=' header-color'>shwo All Product <i className="fa-solid fa-angles-right fa-fade"></i></Link>
        </div>

        {Product.slice(0, 6).map((product) => (
          <div className=" col-sm-6 col-md-4  col-lg-4  col-xl-3  col-xxl-2  p-2" key={product.id}>

            <div className='productContent'>
              <Link to={`/Proudectdetails/${product.id}`} className='text-black'>
                <img src={product.imageCover} alt="Shop Store ecommerce" className='w-100' />
                <span className='text-success fw-bold'>
                  {product.title.split(' ').slice(0, 2).join(' ')}
                </span>
                <p className='text-muted'>{product.description.split(' ').slice(0, 5).join(' ')}</p>
                <div className="d-flex justify-content-between align-items-center">
                  <p>EGP<span className='fw-bold'>{product.price}</span> </p>
                  <p>{product.ratingsAverage} <i className="fa-solid fa-star star-color"></i> ({product.ratingsQuantity})</p>
                </div>
              </Link>
              <button className='btn text-center w-100 text-white AddToCart'>
                Add to Cart <i className="fa-solid fa-cart-plus"></i>
              </button>
              <div className='position-absolute p-2 heartContainer'>
                <i className="fa-regular fa-heart text-muted"></i>
              </div>
            </div>

          </div>
        ))}

        <div className=' my-5 position-relative HomeSection4 '>
          <img src={img19} alt="" className='imgHeader3' />
          <div className="row my-1  g-4">
            <div className="col-sm-6 col-md-6  col-lg-4  col-xl-3  col-xxl-3 ">
              <div className=' bg-white border rounded-3'>
                <img src={img20} alt="" className='w-100' />
                <div className="p-2 ">
                  <h4>Tabitha Brown for Target</h4>
                  <p className='text-muted'>Check out the latest flavors & designs by the actress, vegan & social media phenom.</p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-md-6  col-lg-4  col-xl-3  col-xxl-3 ">
              <div className=' bg-white border rounded-3'>
                <img src={img22} alt="" className='w-100' />
                <div className="p-2 ">
                  <h4>Tabitha Brown for Target</h4>
                  <p className='text-muted'>Check out the latest flavors & designs by the actress, vegan & social media phenom.</p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-md-6  col-lg-4  col-xl-3  col-xxl-3">
              <div className='bg-white border rounded-3'>
                <img src={img23} alt="" className='w-100' />
                <div className="p-2 ">
                  <h4>Tabitha Brown for Target</h4>
                  <p className='text-muted'>Check out the latest flavors & designs by the actress, vegan & social media phenom.</p>
                </div>
              </div>
            </div>
            <div className="col-sm-6 col-md-6  col-lg-4  col-xl-3  col-xxl-3">
              <div className='bg-white border rounded-3'>
                <img src={img21} alt="" className='w-100' />
                <div className="p-2 ">
                  <h4>Tabitha Brown for Target</h4>
                  <p className='text-muted'>Check out the latest flavors & designs by the actress, vegan & social media phenom.</p>
                </div>
              </div>
            </div>

          </div>

        </div>






      </div>
      <div className=' position-relative HomeSection2 mt-2'>
        <img src={img9} alt="" className='imgHeader2 rounded-3' />
        <div className=' position-absolute text-center   top-50 start-25 ContentSimple'>
          <h3 className='text-white my-2'>
            The easiest way to shop and save
          </h3>
          <button className='btn'>Preview the deals</button>
        </div>
      </div>

    </div>
  );
}
