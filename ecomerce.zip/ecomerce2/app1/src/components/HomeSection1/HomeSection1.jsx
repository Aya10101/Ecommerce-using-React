import React from 'react'
import "./HomeSection1.css";
import img10 from '../../img/img10.avif'
import img11 from '../../img/img11.avif'
import img12 from '../../img/img12.avif'
import img13 from '../../img/img13.avif'
import img18 from '../../img/img14.avif'
import img14 from '../../img/img7.webp'
import img15 from '../../img/img8.webp'
import img16 from '../../img/img4.webp'
import img17 from '../../img/img6.webp'

export default function HomeSection1() {
  return <>

<div className="container my-5">
<div className="row  align-items-start justify-content-center">

  <div className="col-sm-12 col-md-12  col-lg-4  col-xl-4  col-xxl-4">
    <div>
      <h4>  More reasons to shop  </h4>
      <div className="row justify-content-center">
        <div className="col-sm-6" role="button">
          <img src={img10} alt=" shop Ecomerce" className='w-100'/>
        </div>
        <div className="col-sm-6" role="button">
          <img src={img11} alt=" shop Ecomerce" className='w-100'/>
        </div>
        <div className="col-sm-6" role="button">
          <img src={img12} alt=" shop Ecomerce" className='w-100'/>
        </div>
        <div className="col-sm-6" role="button">
          <img src={img13} alt=" shop Ecomerce" className='w-100'/>
        </div>
      </div>
    </div>
  </div>
  <div className="col-sm-12 col-md-12  col-lg-4  col-xl-4  col-xxl-4 " role="button">
<h4> in focus  </h4>
<img src={img14} alt="shop Ecomerce" className='w-100 rounded-3' height={370} />
  </div>

  <div className="col-sm-12 col-md-12  col-lg-4  col-xl-4  col-xxl-4 " >
  <h4> Mega deals of the day  </h4>
<div className="row main-color rounded-3 " >
<div className="col-sm-6 p-3 " role="button" >
    <div className='bg-white rounded-3 position-relative p-2'>
    <img src={img16} alt=" shop Ecomerce" className='w-100' />
    <p className='text-muted m-1 fw-bold'>Lenovo IdeaPad 1 15AL7  With 15.6 -Inch +  English/Arabic Abyss Blue </p>
    <h5>Up to 70% off</h5>
    <p className=' position-absolute top-0 end-0  three-color px-2 text-danger rounded-bottom-3'>Fashion deals</p>
    </div>
  </div>
  <div className="col-sm-6 p-3" role="button">
    <div className='bg-white rounded-3 position-relative p-2'>
    <img src={img15} alt=" shop Ecomerce" className='w-100'/>
    <p className='text-muted m-1 fw-bold'>Lenovo IdeaPad 1 15AL7  With 15.6 -Inch +  English/Arabic Abyss Blue </p>
    <h5>Up to 70% off</h5>
    <p className=' position-absolute top-0 end-0  three-color px-2 text-danger rounded-bottom-3'>Fashion deals</p>
    </div>
  </div>
</div>
  </div>


</div>
</div>
  </>
  
}
