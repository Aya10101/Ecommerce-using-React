import React from 'react'
import "./HomeSection2.css";
import img1 from '../../img/img19.avif'
export default function HomeSection2() {
  return <>
<div className='container my-5 position-relative HomeSection2'>
  <img src={img1} alt="" className='imgHeader2' />
  <div className=' position-absolute text-center   top-50 start-50 Content'>
  <h3 className='text-white my-2'>
  the biggest sale of the season 
  </h3>
  <button className='btn'>Preview the deals</button>
  </div>
</div>
  </>
  
}
