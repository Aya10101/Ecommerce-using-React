import React, { useState } from 'react';
import axios from 'axios';
import { useFormik } from 'formik';
import { Link, useNavigate } from 'react-router-dom';
import img1 from '../../img/download.png';
import { Helmet } from "react-helmet";  

export default function Login() {
  let navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [messageError, setMessageError] = useState('');

  function validate(values) {
    let errors = {};

    if (!values.email) {
      errors.email = "Email is Required";
    } else if (!/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)) {
      errors.email = 'Invalid Email address';
    }

    if (!values.password) {
      errors.password = "Password is Required";
    } else if (!/^[a-zA-Z0-9_]{6,18}$/.test(values.password)) {
      errors.password = 'Invalid Password';
    }

    return errors;
  }

  async function handleSubmit(values) {
    setIsLoading(true);
    console.log(values);
    try {
      let { data } = await axios.post("https://ecommerce.routemisr.com/api/v1/auth/signin", values);
      if (data.message === "success") {
        localStorage.setItem("yourToken", data.token);
        setIsLoading(false);
        navigate("/");
      }
    } catch (error) {
      setMessageError(`${error.response.data.message}`);
      setIsLoading(false);
    }
  }

  let formik = useFormik({
    initialValues: {
      email: '',
      password: ''
    },
    validate,
    onSubmit: handleSubmit
  });

  return (
    <>
      <Helmet>
        <meta charSet="utf-8" />
        <title>Login</title>
        <meta name="description" content="Welcome to Your eCommerce Store, the best place to find and purchase the latest products. Shop now for electronics, fashion, home goods, and more. Enjoy fast shipping and excellent customer service." />
        <meta name="keywords" content="ecomerce Shop Store shopping fashion" />
        <link rel="canonical" href="http://mysite.com/example" />
      </Helmet>
      <div className='d-flex justify-content-center align-items-center ContentLogin my-2 py-5'>
        <div className="popup bg-white border text-center position-relative">
          <div className="popup_inner">
            <img src={img1} alt="Login ecommerce shop store online" className='w-100' />
            <div className="mx-4 bg-white">
              <div className="myForm px-4 w-100 text-start">
                <form onSubmit={formik.handleSubmit}>
                  <label htmlFor="email" className='my-2'>Email Address:</label>
                  <input className='form-control' id="email" name="email" type="email" onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.email} />
                  {formik.errors.email && formik.touched.email ? <div className="alert alert-danger">{formik.errors.email}</div> : null}

                  <label htmlFor="password" className='my-2'>Password: </label>
                  <input className='form-control' id="password" name="password" type="password" onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.password} />
                  {formik.errors.password && formik.touched.password ? <div className="alert alert-danger">{formik.errors.password}</div> : null}
                  {messageError ? <div className="alert alert-danger mt-3">{messageError}</div> : null}

                  {isLoading ? <button type='button' className='btn w-100'><i className="fa-solid fa-spinner fa-spin"></i></button> : <button disabled={!formik.isValid || !formik.dirty} className='btn w-100 my-3 btnLogin'> Login</button>}
                </form>
              </div>
            </div>
            <span>Don't have an account? | </span>
            <Link to="/register">Create New Account</Link>
          </div>
        </div>
      </div>
    </>
  );
}
