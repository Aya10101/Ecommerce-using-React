import React, { useContext, useState, useEffect } from 'react';
import 'pretty-checkbox/dist/pretty-checkbox.min.css';
import images from '../../img/images.png';
import { contextApp } from '../ContextApp/ContextApp';
import axios from 'axios';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import {Helmet} from "react-helmet";

export default function MyAllProduct() {
  const { Category, Brand, Product , AddProductToCart } = useContext(contextApp);
  const [Products, setProducts] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [selectedBrand, setSelectedBrand] = useState(null);


  useEffect(() => {
    // Initialize with all products when component mounts
    setProducts(Product);
  }, [Product]);

  async function getspecificCategory(categoryId) {
    try {
      const { data } = await axios.get('https://ecommerce.routemisr.com/api/v1/products', {
        params: {
          category: categoryId,
        },
      });
      
      setProducts(data?.data);
    } catch (error) {
      console.error('Error fetching products by category:', error);
    }
  }

  async function getspecificBrand(brandId) {
    try {
      const { data } = await axios.get('https://ecommerce.routemisr.com/api/v1/products', {
        params: {
          brand: brandId,
        },
      });
      setProducts(data?.data);
    } catch (error) {
      console.error('Error fetching products by brand:', error);
    }
  }

  function handleCategoryChange(categoryId) {
    if (selectedCategory === categoryId) {
      setSelectedCategory(null);
      setProducts(Product); // Reset to all products
    } else {
      setSelectedCategory(categoryId);
      setSelectedBrand(null); // Deselect brand if category is selected
      getspecificCategory(categoryId);
    }
  }

  function handleBrandChange(brandId) {
    if (selectedBrand === brandId) {
      setSelectedBrand(null);
      setProducts(Product); // Reset to all products
    } else {
      setSelectedBrand(brandId);
      setSelectedCategory(null); // Deselect category if brand is selected
      getspecificBrand(brandId);
    }
  }

  async function addTocart(productId) {
    await AddProductToCart(productId);


  }

  return (
    
    <div className="FilterApps mt-5 pt-4 container-fluid d-flex justify-content-center">
       <Helmet>
                <meta charSet="utf-8" />
                <title>All Product</title>
                <meta name="description" content="Welcome to Your eCommerce Store, the best place to find and purchase the latest products. Shop now for electronics, fashion, home goods, and more. Enjoy fast shipping and excellent customer service." />
                <meta name="keywords" content="ecomerce Shop Store shoping fashion"/>
                <link rel="canonical" href="http://mysite.com/example" />
         
            </Helmet>
      <div className="row bg-light w-100">
        <div className="col-md-3 FilterText">
          <div className="d-flex justify-content-between align-items-center border-bottom p-2">
            <div className="d-flex align-items-center">
              <i className="fa-solid fa-sliders"></i> <h5 className='mx-2'>All categories</h5>
            </div>
          </div>

          <div className="d-flex align-items-center justify-content-between my-3 ps-4">
            <div className="pretty p-svg p-curve">
              <input
                type="checkbox"
                checked={!selectedCategory && !selectedBrand}
                onClick={() => {
                  setSelectedCategory(null);
                  setSelectedBrand(null);
                  setProducts(Product);
                }}
              />
              <div className="state p-success">
                <svg className="svg svg-icon" viewBox="0 0 20 20">
                  <path d="M7.629,14.566c0.125,0.125,0.291,0.188,0.456,0.188c0.164,0,0.329-0.062,0.456-0.188l8.219-8.221c0.252-0.252,0.252-0.659,0-0.911c-0.252-0.252-0.659-0.252-0.911,0l-7.764,7.763L4.152,9.267c-0.252-0.251-0.66-0.251-0.911,0c-0.252,0.252-0.252,0.66,0,0.911L7.629,14.566z" style={{ stroke: 'white', fill: 'white' }}></path>
                </svg>
                <label className='text-muted'>All Product</label>
              </div>
            </div>
          </div>

          <div className="accordion" id="accordionExample">
            <div className="accordion-item">
              <h2 className="accordion-header">
                <button className="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  <div className="d-flex align-items-center justify-content-between">
                    <div className="numberContentFilter rounded-circle mx-2">
                      <p className='my-3'>{Category.length}</p>
                    </div>
                    <p className='my-3'><i className="fa-solid fa-building-shield"></i> Show all categories</p>
                  </div>
                </button>
              </h2>
              <div id="collapseOne" className="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                <div className="accordion-body">
                  {Category.map((category) => (
                    <div className="d-flex align-items-center justify-content-between mb-3" key={category._id}>
                      <div className="pretty p-svg p-curve">
                        <input
                          type="checkbox"
                          checked={selectedCategory === category._id}
                          onChange={() => handleCategoryChange(category._id)}
                        />
                        <div className="state p-success">
                          <svg className="svg svg-icon" viewBox="0 0 20 20">
                            <path d="M7.629,14.566c0.125,0.125,0.291,0.188,0.456,0.188c0.164,0,0.329-0.062,0.456-0.188l8.219-8.221c0.252-0.252,0.252-0.659,0-0.911c-0.252-0.252-0.659-0.252-0.911,0l-7.764,7.763L4.152,9.267c-0.252-0.251-0.66-0.251-0.911,0c-0.252,0.252-0.252,0.66,0,0.911L7.629,14.566z" style={{ stroke: 'white', fill: 'white' }}></path>
                          </svg>
                          <label className='text-muted'>{category?.name}</label>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="accordion-item">
              <h2 className="accordion-header">
                <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseTwo">
                  <div className="d-flex align-items-center justify-content-between">
                    <div className="numberContentFilter rounded-circle mx-2">
                      <p className='my-3'>{Brand.length}</p>
                    </div>
                    <p className='my-3'><i className="fa-solid fa-building-shield"></i>Show all Brand</p>
                  </div>
                </button>
              </h2>
              <div id="panelsStayOpen-collapseTwo" className="accordion-collapse collapse show">
                <div className="accordion-body DivContentActionBrand">
                  {Brand.map((brand) => (
                    <div className="d-flex align-items-center justify-content-between mb-3" key={brand._id}>
                      <div className="pretty p-svg p-curve">
                        <input
                          type="checkbox"
                          checked={selectedBrand === brand._id}
                          onChange={() => handleBrandChange(brand._id)}
                        />
                        <div className="state p-success">
                          <svg className="svg svg-icon" viewBox="0 0 20 20">
                            <path d="M7.629,14.566c0.125,0.125,0.291,0.188,0.456,0.188c0.164,0,0.329-0.062,0.456-0.188l8.219-8.221c0.252-0.252,0.252-0.659,0-0.911c-0.252-0.252-0.659-0.252-0.911,0l-7.764,7.763L4.152,9.267c-0.252-0.251-0.66-0.251-0.911,0c-0.252,0.252-0.252,0.66,0,0.911L7.629,14.566z" style={{ stroke: 'white', fill: 'white' }}></path>
                          </svg>
                          <label className='text-muted'>{brand?.name}</label>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-9 py-5 px-5">
          <div>
            <div className="row g-4 justify-content-center">
              {Products.length > 0 ? (
                Products.map((product) => (
                  <div className=" col-sm-6 col-md-4  col-lg-4  col-xl-3  col-xxl-2  p-2" key={product.id}>
            
                <div className='productContent'>
                 <Link to={`/Proudectdetails/${product.id}`}   className='text-black'>
                 <img src={product.imageCover} alt="Shop Store ecommerce" className='w-100' />
                      <span className='text-success fw-bold'>
                        {product.title.split(' ').slice(0, 2).join(' ')}
                      </span>
                      <p className='text-muted'>{product.description.split(' ').slice(0, 5).join(' ')}</p>
                      <div className="d-flex justify-content-between align-items-center">
                        <p>EGP<span className='fw-bold'>{product.price}</span> </p>
                        <p>{product.ratingsAverage} <i className="fa-solid fa-star star-color"></i> ({product.ratingsQuantity})</p>
                      </div>
                 </Link>
                      <button onClick={()=>addTocart(product.id)}  className='btn text-center w-100 text-white AddToCart'>
                        Add to Cart <i className="fa-solid fa-cart-plus"></i>
                      </button>
                      <div className='position-absolute p-2 heartContainer'>
                        <i className="fa-regular fa-heart text-muted"></i>
                      </div>
                    </div>
             
                  </div>
                ))
              ) : (
                <div className="d-flex justify-content-center align-items-center">
                  <img src={images} alt="Shop Store ecommerce" className='w-75' />
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
