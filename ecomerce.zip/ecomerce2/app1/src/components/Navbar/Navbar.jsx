import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../../img/logo.svg';
import { contextApp } from '../ContextApp/ContextApp';

export default function Navbar() {
  let navigate = useNavigate();
  const { CartNumber } = useContext(contextApp);

  function SignOut() {
    localStorage.removeItem('yourToken');
    navigate('/login');
  }

  return (
    <>
      <div className='contentnav position-fixed top-0 star-0 end-0 w-100'>
        <nav className='navbar navbar-expand-lg py-3'>
          <div className='container-fluid'>
            <div className='d-flex me-auto mb-2 mb-lg-0'>
              <Link className='text-decoration-none text-white active px-3' aria-current='page' to='#'>
                <i className='fa-solid fa-location-dot mx-2'></i>Ship to 11678
              </Link>
              <Link className='text-white px-3' to='#'>Thornton</Link>
            </div>
            <div className='d-flex ms-auto mb-2 mb-lg-0 textNavLeft d-lg-block d-none'>
              <Link className='text-white px-3' to='#'>Target Circle™</Link>
              <Link className='text-white px-3' to='#'>Target Circle™ Card</Link>
              <Link className='text-white px-3' to='#'>Target Circle 360™</Link>
              <Link className='text-white px-3' to='#'>Weekly Ad</Link>
              <Link className='text-white px-3' to='#'>Registry</Link>
              <Link className='text-white px-3' to='#'>Find Stores</Link>
            </div>
          </div>
        </nav>

        <nav className='navbar navbar-expand-lg bg-body-tertiary'>
          <div className='container-fluid'>
            <Link className='navbar-brand' to='/'>
              <img src={logo} alt='Ecommerce' width={50} />
            </Link>
            <button
              className='navbar-toggler'
              type='button'
              data-bs-toggle='collapse'
              data-bs-target='#navbarSupportedContent'
              aria-controls='navbarSupportedContent'
              aria-expanded='false'
              aria-label='Toggle navigation'
            >
              <span className='navbar-toggler-icon'></span>
            </button>
            <div className='collapse navbar-collapse' id='navbarSupportedContent'>
              <ul className='navbar-nav me-auto mb-2 mb-lg-0 text-center'>
                <li className='nav-item'>
                  <Link className='nav-link active fw-bold' aria-current='page' to='/'>
                    Home
                  </Link>
                </li>
                <li className='nav-item'>
                  <Link className='nav-link fw-bold' aria-current='page' to='/MyAllProduct'>
                    All Products
                  </Link>
                </li>
                <li className='nav-item'>
                  <Link className='nav-link fw-bold' aria-current='page' to='#'>
                    Categories
                  </Link>
                </li>
                <li className='nav-item'>
                  <Link className='nav-link fw-bold' aria-current='page' to='#'>
                    Brands
                  </Link>
                </li>
                <li className='nav-item'>
                  <Link className='nav-link fw-bold' aria-current='page' to='/Cart'>
                    Cart
                  </Link>
                </li>
                <li className='nav-item'>
                  <a className='nav-link fw-bold' to='#'>
                    New & Featured
                  </a>
                </li>
                <li className='nav-item'>
                  <Link className='nav-link fw-bold' aria-current='page' to='#'>
                    Contact Us
                  </Link>
                </li>
              </ul>

              <ul className='navbar-nav ms-auto mb-2 mb-lg-0 text-center d-flex align-items-center'>
                <li className='nav-item'>
                  <i className='fa-brands fa-facebook ps-2'></i>
                  <i className='fa-brands fa-instagram ps-2'></i>
                  <i className='fa-brands fa-tiktok ps-2'></i>
                  <i className='fa-brands fa-youtube ps-2'></i>
                  <i className='fa-brands fa-twitter ps-2'></i>
                  <i className='fa-brands fa-x-twitter ps-2 pe-4'></i>
                </li>
                {localStorage.getItem('yourToken') != null ? (
                  <li className='nav-item'>
                    <div className='d-flex position-relative p-1'>
                      <Link to='/Cart' className='text-black'>
                        Cart
                      </Link>
                      <i className='fa-solid fa-cart-shopping'></i>
                      {CartNumber > 0 ? (
                        <div className='NumberCartnav position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger'>
                          <span>{CartNumber}</span>
                        </div>
                      ) : null}
                    </div>
                  </li>
                ) : null}

                {localStorage.getItem('yourToken') == null ? (
                  <li className='nav-item'>
                    <Link className='nav-link fw-bold' aria-current='page' to='/login'>
                      Login
                    </Link>
                  </li>
                ) : (
                  <li className='nav-item'>
                    <button className='nav-link fw-bold btn' onClick={SignOut}>
                      SignOut
                    </button>
                  </li>
                )}
              </ul>
            </div>
          </div>
        </nav>
      </div>
    </>
  );
}
