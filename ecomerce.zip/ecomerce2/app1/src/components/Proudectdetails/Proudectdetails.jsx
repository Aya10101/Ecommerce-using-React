import React, { useContext, useEffect, useState } from 'react'
import axios from 'axios';
import { useParams } from 'react-router-dom';
import Slider from "react-slick";
import ReactImageMagnify from 'react-image-magnify';
import { contextApp } from '../ContextApp/ContextApp';
import { Helmet } from "react-helmet";

export default function Proudectdetails() {

  const { AddProductToCart } = useContext(contextApp)


  let { id } = useParams()
  const [details, setDetails] = useState([])
  const [brand, setBrand] = useState({})
  const [catogry, setCatogry] = useState([])
  const [img, setImg] = useState([])

  var settings = {
    dots: true,
    dotsClass: "slick-dots ",
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,

    customPaging: function (i) {
      return (
        <a>
          <img src={img[i]} className='w-100 ' />
        </a>
      );
    },
  };



  async function getProudectdetails(id) {
    let { data } = await axios.get(`https://ecommerce.routemisr.com/api/v1/products/${id}`)
    setDetails(data.data);
    setCatogry(data.data.subcategory)
    setBrand(data.data.brand)
    setImg(data.data.images)

  }

  useEffect(() => {
    getProudectdetails(id)
  }, [])


  async function addTocart(productId) {
    await AddProductToCart(productId);
  }
  return <>
    <Helmet>
      <meta charSet="utf-8" />
      <title>Dedails Product  </title>
      <meta name="description" content="Welcome to Your eCommerce Store, the best place to find and purchase the latest products. Shop now for electronics, fashion, home goods, and more. Enjoy fast shipping and excellent customer service." />
      <meta name="keywords" content="ecomerce Shop Store shoping fashion" />
      <link rel="canonical" href="http://mysite.com/example" />

    </Helmet>
    <div className="container py-5">
      <div key={details._id} className="row my-5 pt-4 align-items-center overflow-hidden ">

        <div className="col-md-4 my-5  ">
          <Slider {...settings}>

            {img?.map((img) => <ReactImageMagnify
              {...{
                smallImage: {
                  alt: 'Zoomed Image',
                  src: img,
                  width: 400,
                  height: 400,

                },
                largeImage: {
                  src: img,
                  width: 1200,
                  height: 900,
                },
                enlargedImagePosition: 'over',

                isHintEnabled: true,

              }}
            />)}
          </Slider>

        </div>
        <div className="col-md-8 ">
          <h3>{details.title}</h3>
          <span>{details.description}</span>
          <div className="d-flex my-2">
            <p className='pe-3'><i className='fas fa-star star-color px-1'></i>{details.ratingsAverage} </p>
            <p > | <i className='fa fa-users ps-2 header-color' ></i> {details.ratingsQuantity} ratings </p>
          </div>




          <h6 className='text-main fw-bold '>Category:<span className='text-black fw-normal ms-1'>{catogry.map((catogry) => <span key={catogry._id} ><span>{catogry.name}</span></span>)}</span></h6>

          <h6 className='text-main fw-bold pt-1'>Brand:<span className='text-black fw-normal ms-1'>{brand.slug}</span></h6>

          <h6 className='text-main fw-bold pt-1'>available quantity:<span className='text-black fw-normal ms-1'>{details.quantity}</span></h6>

          <h6 className='text-main fw-bold pt-1'>Price: <span className='text-danger  ms-1 '>{details.price - 40}EGP</span></h6>


          <button onClick={() => addTocart(details.id)} className="btn text-center w-100 success-colors mt-3 "> Add to Cart <i className="fa-solid fa-cart-plus"></i> </button>
        </div>
      </div>
    </div>


  </>
}
