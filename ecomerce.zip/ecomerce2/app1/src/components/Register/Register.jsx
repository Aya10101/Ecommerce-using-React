import React, { useState } from 'react'
import { Formik, useFormik } from 'formik';
import  axios  from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import {Helmet} from "react-helmet";  

export default function Register() {

  let navigate = useNavigate()
const [isLoading, setIsLoading] = useState(false)
const [massegError, setmassegError] = useState('')
  function validate(values) {
    let errors={}
    if(!values.name)
    {
      errors.name="Name is Required"
    }
    else if (values.name.length< 3)
    {
      errors.name="Name minlength is 3"
    }
    else if (values.name.length> 10)
    {
      errors.name="Name maxlength is 10"
    }
    if(!values.email)
    {
     errors.email="Email is Required";
    }
    else if ( !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email))
    {
     errors.email = 'Invalid Email address';   
    }
    
    if(!values.phone)
    {
     errors.phone="Phone is Required";
    }
    else if ( !/^01[01257][0-9]{8}$/.test(values.phone))
    {
     errors.phone = 'Invalid Phone ';   
    }
    
    if(!values.password)
    {
     errors.password="Password is Required";
    }
    else if ( !/^[a-zA-Z0-9_]{6,18}$/.test(values.password))
    {
     errors.password = 'Invalid Password ';   
    }

  else if(values.password !== values.rePassword )
  {
    errors.rePassword = ' Repassword and Password doesnt match';
  }
  return errors
  }

  async function hendelSupmit(values)
  {
    setIsLoading(true)
        console.log(values);
   let {data} = await axios.post("https://ecommerce.routemisr.com/api/v1/auth/signup", values ).catch((error)=>{
    setmassegError(`${error.response.data.message}`)
    setIsLoading(false)
   })
    if(data.message == "success")
    {
     setIsLoading(false)
       navigate("/login")
        
    }
  }


  
  let formik = useFormik({
  initialValues:{
   name:'',
   email: '',
   phone:'',
   password: '',
   rePassword:''

 },
 
 validate,
 onSubmit:hendelSupmit
 
  })

  return <>
   <Helmet>
                <meta charSet="utf-8" />
                <title>Registar </title>
                <meta name="description" content="Welcome to Your eCommerce Store, the best place to find and purchase the latest products. Shop now for electronics, fashion, home goods, and more. Enjoy fast shipping and excellent customer service." />
                <meta name="keywords" content="ecomerce Shop Store shoping fashion"/>
                <link rel="canonical" href="http://mysite.com/example" />
         
            </Helmet>

    <div className=' d-flex justify-content-center align-items-center ContentLogin py-5 '>
      <div className="popup bg-white border   text-center position-relative">
        <div className="popup_inner">
          <div className="mx-4 bg-white">
            <div className="myForm px-4 w-100 text-start">
            <form onSubmit={formik.handleSubmit} >
        <h4> Create New Account</h4>
        <label htmlFor="name" className='my-2'>Name:</label>
     <input onBlur={formik.handleBlur} className='form-control' id="name" name="name" type="name"  onChange={formik.handleChange} value={formik.values.name}/>
     {formik.errors.name && formik.touched.name ? <div className="alert alert-danger">{formik.errors.name}</div> : null } 
  
        <label htmlFor="email" className='my-2'>Email Address:</label>
     <input className='form-control' id="email" name="email" type="email" onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.email}/>
     {formik.errors.email && formik.touched.email ? <div className="alert alert-danger">{formik.errors.email}</div> : null } 
  
     <label htmlFor="phone" className='my-2'>Phone: </label>
     <input className='form-control' id="phone" name="phone" type="phone" onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.phone}/>
     {formik.errors.phone && formik.touched.phone ? <div className="alert alert-danger">{formik.errors.phone}</div> : null } 
  
     <label htmlFor="Password" className='my-2'>Password: </label>
     <input className='form-control' id="password" name="password" type="Password" onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.Password}/>
     {formik.errors.password && formik.touched.password ? <div className="alert alert-danger">{formik.errors.password}</div> : null } 
  
     <label htmlFor="rePassword" className='my-2'>RePassword: </label>
     <input type="password" className='form-control' id="rePassword" name="rePassword"  onBlur={formik.handleBlur} onChange={formik.handleChange} value={formik.values.rePassword}/>
     {formik.errors.rePassword && formik.touched.rePassword ? <div className="alert alert-danger">{formik.errors.rePassword}</div> : null } 
    
     {massegError? <div className="alert alert-danger mt-3">{massegError}</div>:null}
      {isLoading == true? <button  type='button' className=' btn w-100 my-3 btnLogin '><i class="fa-solid fa-spinner fa-spin"></i></button>:  <button  disabled= {!(formik.isValid&&formik.dirty)} className='btn w-100 my-3 btnLogin '> Registar</button> }
     
     
        </form>
            </div>
          </div>
          <span> have  account? | </span>
          <Link to="/login">Login  </Link>

        </div>
      </div>
    </div>
    </>;

}
