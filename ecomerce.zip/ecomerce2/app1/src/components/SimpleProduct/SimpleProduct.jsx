import React, { useState } from 'react';
import img1 from '../../img/img22.avif'

export default function SimpleProduct() {
  const [angle, setAngle] = useState(0);

  const handlePrev = () => {
    setAngle(angle + 22.5);
  };

  const handleNext = () => {
    setAngle(angle - 22.5);
  };

  return <>


    <div className="container text-center m-auto d-flex justify-content-center flex-column align-items-center pt-5 my-5">


      <div className="holder">  
        <div className="spinner" style={{ transform: `rotateY(${angle}deg)` }}>
          {/* Add your panels here */}
          <div className="panel a"></div>
          <div className="panel b"></div>
          <div className="panel c"></div>
          <div className="panel d"></div>
          <div className="panel e"></div>
          <div className="panel f"></div>
          <div className="panel g"></div>
          <div className="panel h"></div>
          <div className="panel i"></div>
          <div className="panel j"></div>
          <div className="panel k"></div>
          <div className="panel l"></div>
          <div className="panel m"></div>
          <div className="panel n"></div>
          <div className="panel o"></div>
          <div className="panel p"></div>
          {/* End panels */}
          <div className="fade"></div>
        </div>
      </div>
      <div className="pagination d-flex justify-content-center align-items-center mt-5">
        <button type="button" onClick={handlePrev}>&#8592;</button>
        <button type="button" onClick={handleNext}>&#8594;</button>
      </div>
    </div>
    </>
}
