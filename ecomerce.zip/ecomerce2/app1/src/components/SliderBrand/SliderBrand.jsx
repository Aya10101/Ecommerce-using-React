import React from 'react';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import axios from 'axios';
import { useQuery } from 'react-query';

export default function SliderBrand() {
  async function getAllbrands() {
    return await axios.get(`https://ecommerce.routemisr.com/api/v1/brands`);
  }

  const { data, isLoading, isError } = useQuery('brands', getAllbrands, {
    refetchOnMount: false,
    refetchInterval: 1000 * 60 * 60,
  });


  if (isError) {
    return <div>Error loading categories</div>;
  }

  const categories = data?.data?.data || [];

  const settings = {
    dots: true,
    infinite: false,
    speed: 500,
    slidesToShow: 7,
    slidesToScroll: 4,
    initialSlide: 0,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return <>
    {isLoading? <div className="container d-flex justify-content-center">
      <span class="loader"></span>
    </div>: <div className="container my-5">
      <h3>Featured Brand</h3>
      <div className="slider-container " role="button">
        <Slider {...settings}>
          {categories.map((category) => (
            <div key={category._id} className="slider-item">
              <img src={category.image} alt={category.name} className="category-image" />
              {/* <h5>{category.name}</h5> */}
            </div>
          ))}
        </Slider>
      </div>
    </div> }
  
    </>
}
